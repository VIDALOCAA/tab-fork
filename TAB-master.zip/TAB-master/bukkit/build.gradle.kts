dependencies {
    implementation(projects.shared)
    implementation(libs.bstats.bukkit)
    compileOnly(libs.bukkit)
    compileOnly(libs.placeholderapi)
    compileOnly(libs.vault)
    compileOnly(libs.via)
    compileOnly(libs.authlib)
    compileOnly(libs.libsDisguises)
    compileOnly(libs.essentials)
}
