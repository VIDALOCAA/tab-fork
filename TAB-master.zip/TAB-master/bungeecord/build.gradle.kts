dependencies {
    implementation(projects.shared)
    implementation(libs.bstats.bungeecord)
    compileOnly(libs.bungeecord)
    compileOnly(libs.premiumVanish)
    compileOnly(libs.redisBungee)
}
