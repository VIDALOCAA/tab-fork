package me.neznamy.tab.api.event.plugin;

import me.neznamy.tab.api.event.TabEvent;

/**
 * Called when TAB is fully loaded.
 */
public interface TabLoadEvent extends TabEvent {
}
